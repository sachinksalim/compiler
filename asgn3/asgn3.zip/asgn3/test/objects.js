var person = {firstName:"John", lastName:"Doe", age:50, eyeColor:"blue"};
name = person.firstName;