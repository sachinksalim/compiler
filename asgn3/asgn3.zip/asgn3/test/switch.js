function main()
{
    var wflg = 0, tflg = 0;
    var dflg = 0;
    var c;
    switch(c)
    {
        case 'w':
        case 'W':
            wflg = 1;
            break;
        case 't':
        case 'T':
            tflg = 1;
            break;
        case 'd':
            dflg = 1;
            break;
    }
    return 0;
}
main();
