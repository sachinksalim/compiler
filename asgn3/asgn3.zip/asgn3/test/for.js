function main(){
    var i=6;
    for (;i<= 8 && i>= 6 && i!= 7; i++){
        if (i>=0){
            print("yes\n");
        }
        else 
            print("no\n");
    }
    return 0;
}
main();