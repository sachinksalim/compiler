function main(){
    var i=6;
    for (;i<= 8 && i 6.67 && i!= 7; i++){
	var 36a;
	var `$#@name;
        if (i>=0);{
            print("yes\n");
        }
        else 
            print("no\n");
    }
    return 0;
}
main();
