function foo ()
{
    var i = 1;
}

function main(){
    foo();
    return 0;
}
main();
