var x = a
y = 2;
var x = ay = 2;
a = 3;